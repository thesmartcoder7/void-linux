#define _POSIX_C_SOURCE 200809L

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/Xft/Xft.h>
#include <X11/keysym.h>
#include <X11/extensions/Xrandr.h>
#include <Imlib2.h>
#include <security/pam_appl.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pwd.h>
#include <grp.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <signal.h>
#include <errno.h>
#include <limits.h>

#include "../config.h"

#define FIELD_WIDTH 420
#define FIELD_HEIGHT 58
#define MAX_MESSAGE 128

typedef struct {
    Window window;
    int x, y, width, height;
    int primary;
} MonitorWindow;

static const char *username = MINLOGIN_USER;
static char password[MAX_PASSWORD];
static size_t password_len;
static char message[MAX_MESSAGE];
static MonitorWindow *monitors;
static int monitor_count;
static int active_monitor = 0;
static Display *dpy;
static GC gc;
static XftFont *font_username;
static XftFont *font_password;
static XftFont *font_status;
static XftColor color_username, color_placeholder, color_password, color_status;
static Imlib_Image original_background;
static int preview_mode = 0;

static int pam_conversation(
    int num_msg,
    const struct pam_message **msg,
    struct pam_response **resp,
    void *appdata_ptr
) {
    (void)appdata_ptr;
    if (num_msg <= 0 || !msg || !resp)
        return PAM_CONV_ERR;

    struct pam_response *responses =
        calloc((size_t)num_msg, sizeof(*responses));
    if (!responses)
        return PAM_BUF_ERR;

    for (int i = 0; i < num_msg; i++) {
        switch (msg[i]->msg_style) {
        case PAM_PROMPT_ECHO_OFF:
            responses[i].resp = strdup(password);
            if (!responses[i].resp)
                goto fail;
            break;
        case PAM_PROMPT_ECHO_ON:
            responses[i].resp = strdup(username);
            if (!responses[i].resp)
                goto fail;
            break;
        case PAM_ERROR_MSG:
        case PAM_TEXT_INFO:
            break;
        default:
            goto fail;
        }
    }

    *resp = responses;
    return PAM_SUCCESS;

fail:
    for (int i = 0; i < num_msg; i++) {
        if (responses[i].resp) {
            memset(responses[i].resp, 0, strlen(responses[i].resp));
            free(responses[i].resp);
        }
    }
    free(responses);
    return PAM_CONV_ERR;
}

/*
 * Run the user's .xinitrc on the already-running X server. The root greeter
 * authenticates; a short-lived supervisor opens/closes the PAM session, while
 * a grandchild drops privileges before executing user-controlled shell code.
 */
static int authenticate_and_launch(void)
{
    struct passwd *pw = getpwnam(username);
    if (!pw || pw->pw_uid == 0) {
        snprintf(message, sizeof(message), "Configured user is invalid");
        return 0;
    }
    /* Copy NSS-owned strings before PAM modules can perform their own lookups. */
    struct passwd target = *pw;
    char target_name[256], target_home[PATH_MAX], target_shell[PATH_MAX];
    if (snprintf(target_name, sizeof(target_name), "%s", pw->pw_name) >= (int)sizeof(target_name) ||
        snprintf(target_home, sizeof(target_home), "%s", pw->pw_dir) >= (int)sizeof(target_home) ||
        snprintf(target_shell, sizeof(target_shell), "%s", (pw->pw_shell && pw->pw_shell[0]) ? pw->pw_shell : "/bin/sh") >= (int)sizeof(target_shell)) {
        snprintf(message, sizeof(message), "Configured account fields are too long");
        return 0;
    }
    target.pw_name = target_name;
    target.pw_dir = target_home;
    target.pw_shell = target_shell;

    struct pam_conv conv = { .conv = pam_conversation, .appdata_ptr = NULL };
    pam_handle_t *pamh = NULL;
    int result = pam_start(MINLOGIN_PAM_SERVICE, username, &conv, &pamh);
    if (result == PAM_SUCCESS) result = pam_authenticate(pamh, 0);
    if (result == PAM_SUCCESS) result = pam_acct_mgmt(pamh, 0);
    if (result != PAM_SUCCESS) {
        if (pamh) pam_end(pamh, result);
        return 0;
    }

    pid_t supervisor = fork();
    if (supervisor < 0) {
        pam_end(pamh, PAM_SYSTEM_ERR);
        snprintf(message, sizeof(message), "Could not start session");
        return 0;
    }
    if (supervisor == 0) {
        /* The session must not inherit the privileged greeter's X connection. */
        XCloseDisplay(dpy);
        int child_result = pam_setcred(pamh, PAM_ESTABLISH_CRED);
        if (child_result == PAM_SUCCESS) child_result = pam_open_session(pamh, 0);
        if (child_result != PAM_SUCCESS) {
            pam_end(pamh, child_result);
            _exit(1);
        }

        pid_t session = fork();
        if (session == 0) {
            /* Build a clean user environment while still privileged. */
            char **pam_env = pam_getenvlist(pamh);
            clearenv();
            setenv("HOME", target.pw_dir, 1);
            setenv("USER", target.pw_name, 1);
            setenv("LOGNAME", target.pw_name, 1);
            setenv("SHELL", (target.pw_shell && target.pw_shell[0]) ? target.pw_shell : "/bin/sh", 1);
            setenv("DISPLAY", MINLOGIN_DISPLAY, 1);
            setenv("XAUTHORITY", MINLOGIN_USER_XAUTHORITY, 1);
            setenv("XDG_SESSION_TYPE", "x11", 1);
            setenv("PATH", "/usr/local/bin:/usr/bin:/bin", 1);
            if (pam_env) {
                for (char **e = pam_env; *e; e++) {
                    char *eq = strchr(*e, '=');
                    if (eq && eq != *e) {
                        size_t n = (size_t)(eq - *e);
                        char key[256];
                        if (n < sizeof(key)) {
                            memcpy(key, *e, n); key[n] = '\0';
                            /* Do not allow PAM to override session identity. */
                            if (strcmp(key, "HOME") && strcmp(key, "USER") &&
                                strcmp(key, "LOGNAME") && strcmp(key, "DISPLAY") &&
                                strcmp(key, "XAUTHORITY")) setenv(key, eq + 1, 1);
                        }
                    }
                    free(*e);
                }
                free(pam_env);
            }
            if (initgroups(target.pw_name, target.pw_gid) != 0 ||
                setgid(target.pw_gid) != 0 || setuid(target.pw_uid) != 0 ||
                chdir(target.pw_dir) != 0) _exit(126);
            char xinitrc[1024];
            if (snprintf(xinitrc, sizeof(xinitrc), "%s/.xinitrc", target.pw_dir) >= (int)sizeof(xinitrc))
                _exit(126);
            execl("/bin/sh", "sh", xinitrc, (char *)NULL);
            _exit(127);
        }

        int status = 1;
        if (session > 0) {
            while (waitpid(session, &status, 0) < 0 && errno == EINTR) {}
        }
        pam_close_session(pamh, 0);
        pam_setcred(pamh, PAM_DELETE_CRED);
        pam_end(pamh, PAM_SUCCESS);
        _exit(session > 0 && WIFEXITED(status) && WEXITSTATUS(status) == 0 ? 0 : 1);
    }

    int status = 1;
    while (waitpid(supervisor, &status, 0) < 0 && errno == EINTR) {}
    pam_end(pamh, PAM_SUCCESS);
    return WIFEXITED(status) && WEXITSTATUS(status) == 0;
}

static void draw_monitor(int index)
{
    MonitorWindow *m = &monitors[index];
    const int fw = FIELD_WIDTH < m->width - 40 ? FIELD_WIDTH : m->width - 40;
    const int fh = FIELD_HEIGHT;
    const int fx = (m->width - fw) / 2;
    const int fy = (m->height - fh) / 2;
    const int baseline = fy + (fh + font_password->ascent - font_password->descent) / 2;
    XftDraw *xftdraw = XftDrawCreate(dpy, m->window,
        DefaultVisual(dpy, DefaultScreen(dpy)), DefaultColormap(dpy, DefaultScreen(dpy)));
    if (!xftdraw)
        return;

    XSetForeground(dpy, gc, 0x08090b);
    XFillRectangle(dpy, m->window, gc, 0, 0,
                   (unsigned int)m->width, (unsigned int)m->height);

    if (original_background) {
        int iw, ih, crop_w, crop_h, crop_x, crop_y;
        imlib_context_set_image(original_background);
        iw = imlib_image_get_width();
        ih = imlib_image_get_height();

        /* Cover-and-crop: preserve aspect ratio independently per monitor. */
        if ((double)iw / (double)ih > (double)m->width / (double)m->height) {
            crop_h = ih;
            crop_w = (int)((double)ih * m->width / m->height);
            crop_x = (iw - crop_w) / 2;
            crop_y = 0;
        } else {
            crop_w = iw;
            crop_h = (int)((double)iw * m->height / m->width);
            crop_x = 0;
            crop_y = (ih - crop_h) / 2;
        }

        Imlib_Image cropped = imlib_create_cropped_scaled_image(
            crop_x, crop_y, crop_w, crop_h, m->width, m->height);

        if (cropped) {
            imlib_context_set_display(dpy);
            imlib_context_set_visual(DefaultVisual(dpy, DefaultScreen(dpy)));
            imlib_context_set_colormap(DefaultColormap(dpy, DefaultScreen(dpy)));
            imlib_context_set_drawable(m->window);
            imlib_context_set_image(cropped);
            imlib_render_image_on_drawable(0, 0);
            imlib_context_set_image(cropped);
            imlib_free_image();
        }
    }

    /* Username above the field. */
    XGlyphInfo ext;
    XftTextExtents8(dpy, font_username, (const FcChar8 *)username,
                    (int)strlen(username), &ext);
    XftDrawString8(xftdraw, &color_username, font_username,
                   (m->width - (int)ext.xOff) / 2, fy - 38,
                   (const FcChar8 *)username, (int)strlen(username));

    /* Field and subtle outline. */
    XSetForeground(dpy, gc, 0x17191e);
    XFillRectangle(dpy, m->window, gc, fx, fy, (unsigned int)fw, (unsigned int)fh);
    XSetForeground(dpy, gc, 0x656a73);
    XDrawRectangle(dpy, m->window, gc, fx, fy, (unsigned int)fw, (unsigned int)fh);

    if (password_len == 0) {
        const char *placeholder = "password";
        XftTextExtents8(dpy, font_password, (const FcChar8 *)placeholder,
                        (int)strlen(placeholder), &ext);
        XftDrawString8(xftdraw, &color_placeholder, font_password,
                       (m->width - (int)ext.xOff) / 2, baseline,
                       (const FcChar8 *)placeholder, (int)strlen(placeholder));

        /* Cursor visible at the center of every monitor's field. */
        XSetForeground(dpy, gc, 0xe5e7eb);
        XDrawLine(dpy, m->window, gc, m->width / 2,
                  baseline - font_password->ascent,
                  m->width / 2, baseline + font_password->descent);
    } else {
        char masked[MAX_PASSWORD];
        size_t n = password_len < sizeof(masked) ? password_len : sizeof(masked) - 1;
        memset(masked, '*', n);
        masked[n] = '\0';
        XftTextExtents8(dpy, font_password, (const FcChar8 *)masked, (int)n, &ext);
        int tx = (m->width - (int)ext.xOff) / 2;
        XftDrawString8(xftdraw, &color_password, font_password, tx, baseline,
                       (const FcChar8 *)masked, (int)n);
        XSetForeground(dpy, gc, 0xe5e7eb);
        XDrawLine(dpy, m->window, gc, tx + (int)ext.xOff,
                  baseline - font_password->ascent,
                  tx + (int)ext.xOff, baseline + font_password->descent);
    }

    if (message[0]) {
        XftTextExtents8(dpy, font_status, (const FcChar8 *)message,
                        (int)strlen(message), &ext);
        XftDrawString8(xftdraw, &color_status, font_status,
                       (m->width - (int)ext.xOff) / 2, fy + fh + 30,
                       (const FcChar8 *)message, (int)strlen(message));
    }
    XftDrawDestroy(xftdraw);
}

static void redraw_all(void)
{
    for (int i = 0; i < monitor_count; i++)
        draw_monitor(i);
    XFlush(dpy);
}

static int find_monitor(Window window)
{
    for (int i = 0; i < monitor_count; i++)
        if (monitors[i].window == window)
            return i;
    return -1;
}

static int create_monitor_windows(void)
{
    Window root = RootWindow(dpy, DefaultScreen(dpy));
    int n = 0;
    XRRMonitorInfo *rr = XRRGetMonitors(dpy, root, True, &n);

    if (!rr || n < 1) {
        if (rr)
            XRRFreeMonitors(rr);
        monitor_count = 1;
        monitors = calloc(1, sizeof(*monitors));
        if (!monitors)
            return 0;
        monitors[0] = (MonitorWindow) {
            .x = 0, .y = 0,
            .width = DisplayWidth(dpy, DefaultScreen(dpy)),
            .height = DisplayHeight(dpy, DefaultScreen(dpy)),
            .primary = 1
        };
    } else {
        monitor_count = n;
        monitors = calloc((size_t)n, sizeof(*monitors));
        if (!monitors) {
            XRRFreeMonitors(rr);
            return 0;
        }
        for (int i = 0; i < n; i++) {
            monitors[i].x = rr[i].x;
            monitors[i].y = rr[i].y;
            monitors[i].width = rr[i].width;
            monitors[i].height = rr[i].height;
            monitors[i].primary = rr[i].primary;
        }
        XRRFreeMonitors(rr);
    }

    XSetWindowAttributes attrs;
    attrs.override_redirect = True;
    attrs.event_mask = ExposureMask | KeyPressMask | ButtonPressMask;

    for (int i = 0; i < monitor_count; i++) {
        MonitorWindow *m = &monitors[i];
        m->window = XCreateWindow(
            dpy, root, m->x, m->y,
            (unsigned int)m->width, (unsigned int)m->height, 0,
            CopyFromParent, InputOutput, CopyFromParent,
            CWOverrideRedirect | CWEventMask, &attrs);
        XStoreName(dpy, m->window, "minlogin");
        XMapRaised(dpy, m->window);
        if (m->primary)
            active_monitor = i;
    }

    XRaiseWindow(dpy, monitors[active_monitor].window);
    XSetInputFocus(dpy, monitors[active_monitor].window, RevertToParent, CurrentTime);
    return 1;
}

int main(int argc, char **argv)
{
    if (argc == 2 && strcmp(argv[1], "--preview") == 0) {
        preview_mode = 1;
    } else if (argc != 1) {
        fprintf(stderr, "Usage: %s [--preview]\n", argv[0]);
        return EXIT_FAILURE;
    }

    /* Preview runs as the logged-in user on the current X session. It never
       invokes PAM or launches a session. Normal mode is service-only. */
    if (!preview_mode && geteuid() != 0) {
        fprintf(stderr, "minlogin must be launched by its root-owned runit service\n");
        return EXIT_FAILURE;
    }
    if (!preview_mode) {
        if (!getenv("DISPLAY")) setenv("DISPLAY", MINLOGIN_DISPLAY, 1);
        if (!getenv("XAUTHORITY")) setenv("XAUTHORITY", MINLOGIN_ROOT_XAUTHORITY, 1);
    }
    dpy = XOpenDisplay(NULL);
    if (!dpy) {
        fprintf(stderr, "minlogin: cannot open X display\n");
        return EXIT_FAILURE;
    }

    if (!create_monitor_windows()) {
        fprintf(stderr, "minlogin: failed to create monitor windows\n");
        XCloseDisplay(dpy);
        return EXIT_FAILURE;
    }

    gc = XCreateGC(dpy, monitors[0].window, 0, NULL);
    int screen = DefaultScreen(dpy);
    Colormap cmap = DefaultColormap(dpy, screen);
    font_username = XftFontOpenName(dpy, screen, MINLOGIN_USERNAME_FONT);
    font_password = XftFontOpenName(dpy, screen, MINLOGIN_PASSWORD_FONT);
    font_status = XftFontOpenName(dpy, screen, MINLOGIN_STATUS_FONT);
    if (!font_username || !font_password || !font_status) {
        fprintf(stderr, "minlogin: cannot load configured Xft font(s); check config.h and installed fonts\n");
        if (font_username) XftFontClose(dpy, font_username);
        if (font_password) XftFontClose(dpy, font_password);
        if (font_status) XftFontClose(dpy, font_status);
        XFreeGC(dpy, gc);
        XCloseDisplay(dpy);
        return EXIT_FAILURE;
    }
    XftColorAllocName(dpy, DefaultVisual(dpy, screen), cmap, MINLOGIN_USERNAME_COLOR, &color_username);
    XftColorAllocName(dpy, DefaultVisual(dpy, screen), cmap, MINLOGIN_PLACEHOLDER_COLOR, &color_placeholder);
    XftColorAllocName(dpy, DefaultVisual(dpy, screen), cmap, MINLOGIN_PASSWORD_COLOR, &color_password);
    XftColorAllocName(dpy, DefaultVisual(dpy, screen), cmap, MINLOGIN_STATUS_COLOR, &color_status);

    if (access(BACKGROUND_IMAGE, R_OK) == 0)
        original_background = imlib_load_image(BACKGROUND_IMAGE);

    int grab = XGrabKeyboard(dpy, monitors[active_monitor].window, True,
                             GrabModeAsync, GrabModeAsync, CurrentTime);
    if (grab != GrabSuccess) {
        fprintf(stderr, "minlogin: could not grab keyboard\n");
        goto cleanup;
    }

    redraw_all();

    for (;;) {
        XEvent event;
        XNextEvent(dpy, &event);

        if (event.type == Expose) {
            int i = find_monitor(event.xexpose.window);
            if (i >= 0)
                draw_monitor(i);
            continue;
        }

        if (event.type == ButtonPress) {
            int i = find_monitor(event.xbutton.window);
            if (i >= 0) {
                active_monitor = i;
                XGrabKeyboard(dpy, monitors[i].window, True,
                              GrabModeAsync, GrabModeAsync, CurrentTime);
                XSetInputFocus(dpy, monitors[i].window, RevertToParent, CurrentTime);
                redraw_all();
            }
            continue;
        }

        if (event.type != KeyPress)
            continue;

        KeySym key;
        char input[32];
        int count = XLookupString(&event.xkey, input, sizeof(input), &key, NULL);

        if (key == XK_Escape) {
            memset(password, 0, sizeof(password));
            password_len = 0;
            message[0] = '\0';
            if (preview_mode)
                break;
        } else if (key == XK_BackSpace || key == XK_Delete) {
            if (password_len > 0)
                password[--password_len] = '\0';
            message[0] = '\0';
        } else if (key == XK_Return || key == XK_KP_Enter) {
            if (preview_mode) {
                snprintf(message, sizeof(message), "Preview only — no login attempted");
            } else if (password_len == 0) {
                snprintf(message, sizeof(message), "Enter your password");
            } else {
                int ok = authenticate_and_launch();
                memset(password, 0, sizeof(password));
                password_len = 0;
                snprintf(message, sizeof(message), "%s",
                         ok ? "Session ended; enter password to log in again"
                            : "Authentication or session failed");
            }
        } else if (count > 0 && input[0] >= 32 && input[0] != 127
                   && password_len < sizeof(password) - 1) {
            /* Printable single-byte input only; XIM/UTF-8 is not implemented. */
            password[password_len++] = input[0];
            password[password_len] = '\0';
            message[0] = '\0';
        }

        redraw_all();
    }

cleanup:
    memset(password, 0, sizeof(password));
    if (original_background) {
        imlib_context_set_image(original_background);
        imlib_free_image();
    }
    for (int i = 0; i < monitor_count; i++)
        if (monitors[i].window)
            XDestroyWindow(dpy, monitors[i].window);
    free(monitors);
    XftColorFree(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
                 DefaultColormap(dpy, DefaultScreen(dpy)), &color_username);
    XftColorFree(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
                 DefaultColormap(dpy, DefaultScreen(dpy)), &color_placeholder);
    XftColorFree(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
                 DefaultColormap(dpy, DefaultScreen(dpy)), &color_password);
    XftColorFree(dpy, DefaultVisual(dpy, DefaultScreen(dpy)),
                 DefaultColormap(dpy, DefaultScreen(dpy)), &color_status);
    XftFontClose(dpy, font_username);
    XftFontClose(dpy, font_password);
    XftFontClose(dpy, font_status);
    XFreeGC(dpy, gc);
    XCloseDisplay(dpy);
    return EXIT_FAILURE;
}
